using System;
using System.Collections.Generic;
using System.Text;

namespace Model
{
    public class Discuss:LogKind
    {
        public Discuss()
        { 
        
        }
        public Discuss(int __logkindid)
        {
            base.logkindid = __logkindid;
        }
        public Discuss(int __logkindid, int __userid)
        {
            base.logkindid = __logkindid;
            base.userid = __userid;
        }
        public Discuss(int __logkindid,int __userid,int __pinguserid,string __pingcontenct,bool __zan)
        {
            base.logkindid = __logkindid;
            base.userid = __userid;
            _pinguserid = __pinguserid;
            _pingcontenct = __pingcontenct;
            _zan = __zan;
        }
        #region Model
        private int _id;
        private int _logkindid;
        private DateTime _pingdate=DateTime.Now;
        private int _pinguserid;
        private string _pingcontenct;
        private bool _zan;
        /// <summary>
        /// 
        /// </summary>
        public int id
        {
            set { _id = value; }
            get { return _id; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int logkindid
        {
            set { _logkindid = value; }
            get { return _logkindid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public DateTime pingdate
        {
            set { _pingdate = value; }
            get { return _pingdate; }
        }
        /// <summary>
        /// 
        /// </summary>
        public int pinguserid
        {
            set { _pinguserid = value; }
            get { return _pinguserid; }
        }
        /// <summary>
        /// 
        /// </summary>
        public string pingcontenct
        {
            set { _pingcontenct = value; }
            get { return _pingcontenct; }
        }
        /// <summary>
        /// 
        /// </summary>
        public bool zan
        {
            set { _zan = value; }
            get { return _zan; }
        }
        #endregion Model

    }
}
