using System;
using System.Collections.Generic;
using System.Text;

namespace Model
{
    public class Message
    {
        private int _msgid = 0;
        public int msgid { get { return _msgid; } set { _msgid = value; } }

        private int _msguserid = 0;
        public int msguserid { get { return _msguserid; } set { _msguserid = value; } }

        private string _msg = "";
        public string msg { get { return _msg; } set { _msg = value; } }

        private DateTime _msgdate = DateTime.Now;
        public DateTime msgdate { get { return _msgdate; } set { _msgdate = value; } }

        private string _msgusername = "";
        public string msgusername { get { return _msgusername; } set { _msgusername = value; } }
    }
}
