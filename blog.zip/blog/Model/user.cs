using System;
using System.Collections.Generic;
using System.Text;

namespace Model
{
    public class user
    {
        private int _userid = 0;
        public int userid { get { return _userid; } set { _userid = value; } }

        private string _name = "";
        public string name { get { return _name; } set { _name = value; } }

        private string _relname = "";
        public string relname { get { return _relname; } set { _relname = value; } }

        private string _pwd = "";
        public string pwd { get { return _pwd; } set { _pwd = value; } }

        private string _pic = "";
        public string pic { get { return _pic; } set { _pic = value; } }

        private string _email = "";
        public string email { get { return _email; } set { _email = value; } }

        private int _tel = 0;
        public int tel { get { return _tel; } set { _tel = value; } }

    }
}
