using System;
using System.Collections.Generic;
using System.Text;

namespace Model
{
    public class Photo
    {
        public Photo() { }

        private int _id = 0;
        public int id { get { return _id; } set { _id = value; } }

        private int _photouserid = 0;
        public int photouserid { get { return _photouserid; } set { _photouserid = value; } }

        private string _photodescription = "";
        public string photodescription { get { return _photodescription; } set { _photodescription = value; } }

        private string _photomapsrc = "";
        public string photomapsrc { get { return _photomapsrc; } set { _photomapsrc = value; } }

        private DateTime _photodate = DateTime.Now;
        public DateTime photodate { get { return _photodate; } set { _photodate = value; } }
    }
}
