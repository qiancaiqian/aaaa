using System;
using System.Collections.Generic;
using System.Text;

namespace Model
{
    public class LogKind
    {
        public LogKind()
        {
        }
        public LogKind(int __userid)
        {
            _userid = __userid;
        }
        public LogKind(int __userid,int __logkindid, string __logkind)
        {
            _userid = __userid;
            _logkindid = __logkindid;
            _logkind = __logkind;
        }
        public LogKind(int __userid,string __logkind)
        {
            _userid = __userid;
            _logkind = __logkind;
        }

        private int _logkindid = 0;
        public int logkindid { get { return _logkindid; } set { _logkindid = value; } }

        private int _userid = 0;
        public int userid { get { return _userid; } set { _userid = value; } }

        private string _logkind = "";
        public string logkind { get { return _logkind; } set { _logkind = value; } }

        private int _msgid = 0;
        public int msgid { get { return _msgid; } set { _msgid = value; } }
    }
}
