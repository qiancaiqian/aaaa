using System;
using System.Collections.Generic;
using System.Text;

namespace Model
{
    [Serializable]
    public class LogView : LogKind
    {
        public LogView(){}

        public LogView(int __logid,object obj) { _logid = __logid; }

        public LogView(int __userid) { base.userid = __userid;}
        public LogView(int __userid, int __logkndid) { base.userid = __userid; base.logkindid = __logkndid; }
        private int _logid = 0;
        public int logid { get { return _logid; } set { _logid = value; } }

        private string _logtitle = "";
        public string logtitle { get { return _logtitle; } set { _logtitle = value; } }

        private string _logcontenct = "";
        public string logcontenct { get { return _logcontenct; } set { _logcontenct = value; } }

        private DateTime _logdate = DateTime.Now;
        public DateTime logdate { get { return _logdate; } set { _logdate = value; } }

    }
}
