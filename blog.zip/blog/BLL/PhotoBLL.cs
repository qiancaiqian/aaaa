using System;
using System.Collections.Generic;
using System.Text;
using Model;
using DAL;

namespace BLL
{
    public class PhotoBLL
    {
        private PhotoDAL pa;
        public PhotoBLL() { pa = new PhotoDAL(); }

        public bool InsertPhoto(Photo p)
        {
            int result = pa.InsertPhoto(p);
            if (result==1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public List<Photo> GetPhotoS(int userid)
        {
            List<Photo> lp = pa.GetPhoto();
            List<Photo> _p = new List<Photo>();
            if (userid != 0)
            {
                foreach (Photo p in lp)
                {
                    if (p.photouserid == userid)
                    {
                        _p.Add(p);
                    }
                }
            }
            else
            {
                _p = lp;
            }
            return _p;
        }
        public Photo GetPhoto(int id)
        {
            return pa.GetPhoto(id);
        }

        public bool UpdatePhoto(Photo p)
        {
            int result = pa.UpdatePhoto(p);
            if (result==1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool DeletePhoto(int id)
        {
            int result = pa.DeletePhoto(id);
            if (result == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
