using System;
using System.Collections.Generic;
using System.Text;
using Model;
using DAL;

namespace BLL
{
    public class MessageBLL
    {
        private MessageDAL ma;
        public MessageBLL() { ma = new MessageDAL(); }
        public List<Message> GetMessages()
        {
            List<Message> lm = ma.GetMessages();
            return lm;
        }

        public List<Message> GetTopMessage(int userid)
        {
            List<Message> lm = ma.GetMessages();
            List<Message> l = new List<Message>();
            for (int i = 0; i < lm.Count; i++)
            {
                if (i<8)
                {
                    l.Add(lm[i]);
                }
                else
                {
                    break;
                }
            }
            return l;
        }

        public bool InsertMessage(Message m)
        {
            int result = ma.InsertMessage(m);
            if (result==1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public Message GetSingleMessage(int msgid)
        {
            return ma.GetSingleMessage(msgid);
        }
        public bool UpdateMessage(Message m)
        {
            int result = ma.UpdateMessage(m);
            if (result==1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool DeleteMessage(int msgid)
        {
            int result = ma.DeleteMessage(msgid);
            if (result == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
