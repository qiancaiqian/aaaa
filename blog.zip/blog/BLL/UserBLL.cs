using System;
using System.Collections.Generic;
using System.Text;
using DAL;
using Model;

namespace BLL
{
    public class UserBLL
    {
        private UserDAL ua = null;
        public UserBLL()
        {
            ua = new UserDAL();
        }
        /// <summary>
        /// �жϵ�ǰ�û����Ƿ����
        /// </summary>
        /// <param name="name">�û���</param>
        /// <returns></returns>
        public bool ExitUser(string name)
        {
            int result = ua.ExitUser(name);
            if (result>0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// �ж��û����������Ƿ�һ�·��ص�¼�û�ʵ��
        /// </summary>
        /// <param name="name">�û���</param>
        /// <param name="pwd">��д������</param>
        /// <returns></returns>
        public user CheckUser(string name, string pwd)
        {
            user u = ua.CheckUser(name);
            return u;
        }
        /// <summary>
        /// �����û�
        /// </summary>
        /// <param name="u">�û�ʵ��</param>
        /// <returns></returns>
        public bool InsertUser(user u)
        {
            int result = ua.InsertUser(u);
            if (result == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// �޸��û���Ϣ
        /// </summary>
        /// <param name="u">Ҫ�޸ĵ��û�ʵ����Ϣ</param>
        /// <returns></returns>
        public bool UpdateUser(user u)
        {
            int result = ua.UpdateUser(u);
            if (result == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// ģ����ѯ��ȡ�û���Ϣ
        /// </summary>
        /// <param name="kind">��ѯ�����ֶ�</param>
        /// <param name="value">�ֶε�ֵ</param>
        /// <returns></returns>
        public List<user> GetUsers(string kind, string value)
        {
            return ua.GetUsers(kind, value);
        }

        public List<user> GetUsers(int userid)
        {
            List<user> lu=ua.GetUsers();
            //List<user> _u = new List<user>();
            //if (userid!=0)
            //{
            //    foreach (user u in lu)
            //    {
            //        if (u.userid == userid)
            //        {
            //            _u.Add(u);
            //            break;
            //        }
            //    }
            //}
            //else
            //{
            //    _u = lu;
            //}
            return lu;
        }

        public user GetSingleUsers(int userid)
        {
            return ua.GetSingleUsers(userid);
        }

        public bool DeleteUser(int userid)
        {
            int result = ua.DeleteUser(userid);
            if (result==1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
