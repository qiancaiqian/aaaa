using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using Model;
using DAL;
//|��|��|5|1|a|s|p|x

namespace BLL
{
    public class DiscussBll
    {
        private DiscussDAL da;
        public DiscussBll() { da = new DiscussDAL(); }
        public DataSet GetDiscuss(Discuss dis)
        {
            DataSet ds = da.GetDiscuss(dis);
            return ds;
        }
        public DataTable GetPing(DataTable dt, int logkindid)
        {
            DataTable ping = dt.Clone();
            ping.Columns.Add("zancount", typeof(int));
            int coun = 0;
            foreach (DataRow dr in dt.Rows)
            {
                if (Convert.ToInt32(dr["logkindid"])==logkindid)
                {
                    DataRow _dr = ping.NewRow();
                    for (int i = 0; i < dt.Columns.Count; i++)
                    {
                        _dr[dt.Columns[i].ColumnName] = dr[dt.Columns[i].ColumnName];
                    }
                    ping.Rows.Add(_dr);
                    if (Convert.ToBoolean(dr["zan"]))
                    {
                        coun++;
                    }
                }
            }
            for (int i = 0; i < ping.Rows.Count; i++)
            {
                ping.Rows[i]["zancount"] = coun;
            }
            return ping;
        }
        public DataRow GetAuthor(DataTable dt,int userid)
        {
            DataRow dr = null;
            foreach (DataRow _dr in dt.Rows)
            {
                if (Convert.ToInt32(_dr["userid"])==userid)
                {
                    dr = _dr;
                    break;
                }

            }
            return dr;
        }

        public Discuss GetDiscuss(int logkindid, int pinguserid)
        {
            return da.GetDiscuss(logkindid, pinguserid);
        }
        public bool ExitDicuss_Zan(int logkindid, int pinguserid)
        {
            int result = da.ExitDicuss_Zan(logkindid, pinguserid);
            if (result>0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool InsertDiscuss_Zan(Discuss dis)
        {
            int result = da.InsertDiscuss_Zan(dis);
            if (result > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool UpdateDisscuss_zan(Discuss dis)
        {
            int result = da.UpdateDisscuss_zan(dis);
            if (result > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool DeleteDiscuss(int id)
        {
            int result = da.DeleteDiscuss(id);
            if (result ==1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public int GetDiscussCount(int logkinid)
        {
            return da.GetDiscussCount(logkinid);
        }
    }
}
