using System;
using System.Collections.Generic;
using System.Text;
using Model;
using DAL;
using ShareLibrary;

namespace BLL
{
    public class ArticleManagementBLL
    {
        private ArticleManagementDAL acd = null;
        private ShareResult sr = null;
        public ArticleManagementBLL()
        {
            acd = new ArticleManagementDAL();
            sr = new ShareResult();
        }
        public bool InsertLogView(LogView lo)
        {
            return sr.GetBoolenResult(acd.InsertLogView(lo), 1);
        }
        public bool InsertLogKind(LogKind lk)
        {
            return sr.GetBoolenResult(acd.InsertLogKind(lk), 1);
        }
        public bool UpdateLogView(LogView lo)
        {
            return sr.GetBoolenResult(acd.UpdateLogView(lo), 1);
        }
        public bool UpdateLogKind(LogKind lk)
        {
            return sr.GetBoolenResult(acd.UpdateLogKind(lk), 1);
        }
        public bool DeleteLogView(int logid)
        {
            return sr.GetBoolenResult(acd.DeleteLogView(logid), 1);
        }
        public bool DeleteLogKind(LogKind lk)
        {
            return sr.GetBoolenResult(acd.DeleteLogKind(lk), 1); ;
        }
        public List<LogView> GetLogView(int userid, int logkindid)
        {
            return acd.GetLogView(userid,logkindid);
        }
        public List<LogKind> GetAllKind(LogKind lk)
        {
            return acd.GetAllKind(lk);
        }
        public List<LogKind> GetAllDrop(LogKind lk)
        {
            List<LogKind> lok = new List<LogKind>();
            LogKind log = new LogKind();
            log.logkind = "--��ѡ��--";
            log.logkindid =0;
            log.userid = 0;
            lok.Add(log);
            List<LogKind> l=acd.GetAllKind(lk);
            for (int i = 0; i < l.Count; i++)
            {
                lok.Add(l[i]);
            }
            return lok;
        }

        public bool GetAllKind(List<LogKind> lk,string logkind)
        {
            bool exit = false;
            foreach (LogKind _lk in lk)
            {
                if (_lk.logkind==logkind)
                {
                    exit = true;
                }
            }
            return exit;
        }
    }
}
