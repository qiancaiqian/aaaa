using System;
using System.Collections.Generic;
using System.Text;

namespace ShareLibrary
{
   public class ShareResult
   {
       public bool GetBoolenResult(int result,int compare)
       {
           if (result>=compare)
           {
               return true;
           }
           else
           {
               return false;
           }
       }
   }
}
