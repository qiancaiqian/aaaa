using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.Web;
using System.Collections;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI;
using System.IO;


namespace ShareLibrary
{
    public class Picture
    {
        public string[] SavePicture(string url,FileUpload fiu)
        {
            string fillname, type, Fillname;
            string[] Path = new string[2];
            Page p = new Page();
            if (!string.IsNullOrEmpty(fiu.PostedFile.FileName))
            {
                fillname = fiu.PostedFile.FileName.ToString();
                type = fiu.PostedFile.ContentType;
                if (type == "image/jpeg" || type == "image/png" || type == "image/gif" || type == "image/pjpeg" || type == "image/x-png")
                {
                    int i = fillname.LastIndexOf(".");
                    int j = fillname.Length;
                    string suffy = fillname.Substring(i, j - i);//��ȡͼƬ��׺��
                    Fillname = Guid.NewGuid().ToString();
                    Path[1] = p.Server.MapPath(url) + Fillname.Trim() + suffy;
                    Path[0] = url + Fillname + suffy;
                    fiu.SaveAs(Path[1]);
                }
                return Path;
            }
            else
            {
                Path[0] = "";
                Path[1] = "";
                return Path;
            }
        }

        /// ��СͼƬ
        /// </summary>
        /// <param name="strOldPic">Դͼ�ļ���(����·��)</param>
        /// <param name="strNewPic">��С�󱣴�Ϊ�ļ���(����·��)</param>
        /// <param name="intWidth">��С������</param>
        /// <param name="intHeight">��С���߶�</param>
        public string SmallPic(string strOldPic, string strNewPic, int intWidth, int intHeight)
        {
            System.Drawing.Bitmap objPic, objNewPic;
            Page p = new Page();
            string _objNewPic = "";
            try
            {
                if (strOldPic == "default.jpg")
                {
                    objPic = new System.Drawing.Bitmap(p.Server.MapPath(strNewPic + strOldPic));
                    objNewPic = new System.Drawing.Bitmap(objPic, intWidth, intHeight);
                    _objNewPic = strNewPic + Guid.NewGuid().ToString() + ".jpg";
                    objNewPic.Save(p.Server.MapPath(_objNewPic));
                }
                else
                {
                    objPic = new System.Drawing.Bitmap(p.Server.MapPath(strOldPic));
                    objNewPic = new System.Drawing.Bitmap(objPic, intWidth, intHeight);
                    string suffer = strOldPic.Substring(strOldPic.LastIndexOf("."), strOldPic.Length - strOldPic.LastIndexOf("."));
                    _objNewPic = strNewPic + Guid.NewGuid().ToString() + suffer;
                    objNewPic.Save(p.Server.MapPath(_objNewPic));
                    
                }
            }
            catch (Exception exp)
            { _objNewPic = strOldPic; }
            finally
            {
                objPic = null;
                objNewPic = null;
            }
            return _objNewPic;
        }


    }
}
