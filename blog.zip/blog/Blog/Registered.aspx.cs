﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using BLL;
using Model;
using ShareLibrary;
using System.IO;

public partial class Registered : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Request["userid"] != null)
            {
                hiduserid.Value = Request["userid"].ToString();
            }
            else
            {
                hiduserid.Value = "0";
            }
            if (Request["name"] != null)
            {
                hidname.Value = Request["name"].ToString();
            }
            else
            {
                hidname.Value = "youke";
            }
        }
    }
    protected void btnregis_Click(object sender, EventArgs e)
    {
        if (string.IsNullOrEmpty(txtname.Text))
        {
            Page.ClientScript.RegisterClientScriptBlock(Page.GetType(),"key","alert('用户名不能为空')",true);
            return;
        }
        else if (string.IsNullOrEmpty(txtpwd.Text))
        {
            Page.ClientScript.RegisterClientScriptBlock(Page.GetType(), "key", "alert('密码不能为空')", true);
            return;
        }
        else if (string.IsNullOrEmpty(txtpwdagin.Text))
        {
            Page.ClientScript.RegisterClientScriptBlock(Page.GetType(), "key", "alert('请再次确认密码')", true);
            return;
        }
        else if (string.IsNullOrEmpty(txtrelname.Text))
        {
            Page.ClientScript.RegisterClientScriptBlock(Page.GetType(), "key", "alert('真实姓名不能为空')", true);
            return;
        }
        else if (!string.IsNullOrEmpty(txtemail.Text)&&txtemail.Text.IndexOf("@")==-1)
        {
            Page.ClientScript.RegisterClientScriptBlock(Page.GetType(), "key", "alert('电子邮件格式不对')", true);
            return;
        }
        else
        {
            UserBLL ub = new UserBLL();
            user u = new user();
            Picture p = new Picture();
            u.name = txtname.Text;
            u.pwd = txtpwd.Text;
            u.relname = txtrelname.Text;
            u.tel = Convert.ToInt32(txttelphone.Text);
            u.email = u.email;
            if (ub.ExitUser(txtname.Text))
            {
                Page.ClientScript.RegisterClientScriptBlock(Page.GetType(), "key", "alert('此用户名已经存在')", true);
                return;
            }
            else if (txtpwdagin.Text != txtpwd.Text)
            {
                Page.ClientScript.RegisterClientScriptBlock(Page.GetType(), "key", "alert('密码不一致')", true);
                return;
            }
            else
            {

                string[] pictures = p.SavePicture("images/user/", filepic);
                u.pic = pictures[0];
                if (u.pic != "")
                {
                    u.pic = p.SmallPic(u.pic, "images/user/", 100, 100);
                }
                else
                {
                    u.pic = p.SmallPic("default.jpg", "images/user/", 100, 100);
                }
                if (ub.InsertUser(u))
                {
                    Page.ClientScript.RegisterClientScriptBlock(Page.GetType(), "key", "alert('注册成功')", true);
                    hidname.Value = u.name;
                }
                impic.ImageUrl = u.pic;
            }
        }
    }

    protected void btnLogin_Click(object sender, EventArgs e)
    {
        if (hidname.Value!="")
        {
            Response.Redirect("Login.aspx?name=" + hidname.Value);
        }
        else
        {
            Response.Redirect("Login.aspx?name=youke&&userid=0");
        }
    }

    protected void liBackHome_Click(object sender, EventArgs e)
    {
        Response.Redirect("Home.aspx?name="+hidname.Value+"&&userid=" + hiduserid.Value);
    }
}
