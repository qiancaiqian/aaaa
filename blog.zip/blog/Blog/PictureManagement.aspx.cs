﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Model;
using BLL;
using System.Collections.Generic;
using ShareLibrary;

public partial class PictureManagement : System.Web.UI.Page
{
    private UserBLL ub = new UserBLL();
    private List<user> lu = new List<user>();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            hiduserid.Value = Request["userid"].ToString();
            hidid.Value = hiduserid.Value;
            BindUser(Convert.ToInt32(hiduserid.Value));
            if (hiduserid.Value=="0")
            {
                left.Attributes.Add("style", "");
                right.Attributes.Add("style", "width:100%;height:250px;");
                Panel1.Visible = false;
            }
            else
            {
                left.Attributes.Add("style", "float:left;width:250px;height:222px;");
               right.Attributes.Add("style", "float:left;width:520px;height:auto;");
            }
            if (Request["name"] != null)
            {
                hidname.Value = Request["name"].ToString();
            }
            else
            {
                hidname.Value = "youke";
            }
            string _name = hidname.Value == "youke" ? "游客" : hidname.Value;
            Label2.Text = "当前用户:" + _name;
        }
    }

    protected void repusers_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        Label lbid = null;
        if (e.CommandName=="_edit")
        {
            lbid = (Label)e.Item.FindControl("lbid");
            hidid.Value = lbid.Text;
            user u = ub.GetSingleUsers(Convert.ToInt32(hidid.Value));
            txtname.Text = u.name;
            txtphone.Text = u.tel.ToString();
            txtemail.Text = u.email;
            txtpwd.Text = u.pwd;
            txtrelname.Text = u.relname;
        }
        else if(e.CommandName=="_del")
        {
            lbid = (Label)e.Item.FindControl("lbid");
            ub.DeleteUser(Convert.ToInt32(hiduserid.Value));
            hiduserid.Value = "0";
            hidname.Value = "youke";
            Label2.Text = "当前用户:游客";
            left.Attributes.Add("style", "");
            right.Attributes.Add("style", "width:100%;height:250px;");
            Panel1.Visible = false;
            BindUser(Convert.ToInt32(hiduserid.Value));
            
        }
    }
    protected void repusers_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        Label lblid = null;
        Label lbid = null;
        LinkButton liedit = null;
        LinkButton lidel = null;
        if (e.Item.ItemType==ListItemType.Item||e.Item.ItemType==ListItemType.AlternatingItem)
        {
            lbid = (Label)e.Item.FindControl("lbid");
            lblid = (Label)e.Item.FindControl("Label1");
            int bianhao=e.Item.ItemIndex + 1;
            lblid.Text = bianhao.ToString();
            
            liedit = (LinkButton)e.Item.FindControl("liedit");
            lidel = (LinkButton)e.Item.FindControl("lidel");
            if (hiduserid.Value == "0"||lbid.Text!=hiduserid.Value)
            {
                liedit.Enabled = false;
                lidel.Enabled = false;
            }
            else
            {
                liedit.Enabled = true;
                lidel.Enabled = true;
            }
        }
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        if (txtname.Text=="用户名不能为空")
        {
            Page.ClientScript.RegisterClientScriptBlock(Page.GetType(), "key", "alert('')", true);
            return;
        }
        else if (txtpwd.Text == "")
        {
            Page.ClientScript.RegisterClientScriptBlock(Page.GetType(), "key", "alert('密码不能为空')", true);
            return;
        }
        else if (txtrelname.Text == "")
        {
            Page.ClientScript.RegisterClientScriptBlock(Page.GetType(), "key", "alert('真实姓名不能为空')", true);
            return;
        }
        else if(txtpwd.Text!=txtpwdagin.Text)
        {
            Page.ClientScript.RegisterClientScriptBlock(Page.GetType(), "key", "alert('密码不一致')", true);
            return;
        }
        else
        {
            user u = new user();
            Picture p = new Picture();
            u.userid = Convert.ToInt32(hidid.Value);
            u.name = txtname.Text;
            u.tel =txtphone.Text==""?123456: Convert.ToInt32(txtphone.Text);
            u.email = txtemail.Text;
            u.pwd = txtpwd.Text;
            u.relname = txtrelname.Text;
            string[] pictures = p.SavePicture("images/user/", FileUpload1);
            u.pic = pictures[0];
            if (u.pic != "")
            {
                u.pic = p.SmallPic(u.pic, "images/user/", 100, 100);
            }
            else
            {
                u.pic = p.SmallPic("default.jpg", "images/user/", 100, 100);
            }
            ub.UpdateUser(u);
            BindUser(Convert.ToInt32(hiduserid.Value));
        }
    }

    private void BindUser(int userid)
    {
        lu = ub.GetUsers(userid);
        repusers.DataSource = lu;
        repusers.DataBind();
    }
    private void BindUser(List<user> lu)
    {
        repusers.DataSource = lu;
        repusers.DataBind();
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        if (txtsearch.Text=="")
        {
            Page.ClientScript.RegisterClientScriptBlock(Page.GetType(), "key", "alert('查询内容不能为空'", true);
            return;
        }
        else
        {
            lu = ub.GetUsers(drpsearch.SelectedValue, txtsearch.Text);
            BindUser(lu);
        }
    }
    protected void liBackHome_Click(object sender, EventArgs e)
    {
        Response.Redirect("Home.aspx?name=" + hidname.Value + "&&userid=" + hiduserid.Value);
    }
}
