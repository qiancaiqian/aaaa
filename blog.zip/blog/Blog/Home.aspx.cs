﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Model;
using BLL;
using ShareLibrary;
using System.Collections.Generic;

public partial class Home : System.Web.UI.Page
{
    private ArticleManagementBLL ab = null;
    private  List<LogView> lv = null;
    private List<Model.Message> lm = null;
    private MessageBLL mb;
    public Home() 
    { 
        ab = new ArticleManagementBLL();
        mb = new MessageBLL();
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Request["name"] == null)
            {
                lbtitle.Text = "博客管理(游客，欢迎您使用本博客系统)";
                hiduserid.Value = "0";
                hidname.Value ="youke";
            }
            else
            {
                hiduserid.Value=Request["userid"].ToString();
                hidname.Value = Request["name"].ToString();
                lbname.Text = hidname.Value;
                if (hidname.Value == "youke")
                {
                    lbtitle.Text = "博客管理(游客，欢迎您使用本博客系统)";
                }
                else
                {
                    lbtitle.Text = "博客管理(管理员" + lbname.Text + "，欢迎您使用本博客系统)";
                }
            }
            BindLogs(Convert.ToInt32(hiduserid.Value));
            BindMessage(Convert.ToInt32(hiduserid.Value));
        }
    }
    
    private void BindMessage(int userid)
    {
        lm = mb.GetMessages();
        if (lm.Count==0)
        {
            repmessage.Visible = false;
        }
        else
        {
            repmessage.Visible = true;
            repmessage.DataSource = lm;
            repmessage.DataBind();
        }
    }
    private void BindLogs(int userid)
    {
        lv = ab.GetLogView(userid,0);
        if (lv.Count==0)
        {
            repArictle.Visible = false;
        }
        else
        {
            repArictle.Visible = true;
            repArictle.DataSource = lv;
            repArictle.DataBind();
        }
    }

    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("Registered.aspx");
    }

    protected void btnLogin_Click1(object sender, EventArgs e)
    {
        Response.Redirect("Login.aspx");
    }

    protected void repArictle_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        if (e.Item.ItemType==ListItemType.Item||e.Item.ItemType==ListItemType.AlternatingItem)
        {
            LinkButton lititle = (LinkButton)e.Item.FindControl("lititle");//
            Label lblogkindid = (Label)e.Item.FindControl("lblogkindid");
            Label lbuserid = (Label)e.Item.FindControl("lbuserid");
            //lititle.Attributes.Add("onclick", "ArctileSrc('"+hiduserid.Value+"','"+hidname.Value+"''" + lbuserid.Text + "','" + lblogkindid.Text + "')");
        }
    }
    protected void repmessage_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        Label lbmsgid=null;
        Label lbmsguserid = null;
        if (e.Item.ItemType==ListItemType.Item||e.Item.ItemType==ListItemType.AlternatingItem)
        {
            LinkButton limsg = (LinkButton)e.Item.FindControl("limsg");
            lbmsguserid = (Label)e.Item.FindControl("lbmsguserid");
            lbmsgid=(Label)e.Item.FindControl("lbmsgid");
            limsg.Text = lm[e.Item.ItemIndex].msg;
            if (limsg.Text.Length>=10)
            {
                limsg.ToolTip = limsg.Text;
                limsg.Text = limsg.ToolTip.Substring(0, 6) + "...";
            }
            if (lbmsguserid.Text != hiduserid.Value)
            {
                limsg.Enabled = false;
            }
            else
            {
                limsg.Enabled = true;
                limsg.PostBackUrl = "Message.aspx?msgid=" + lbmsgid.Text + "&&userid=" + hiduserid.Value;
            }
        }
        
    }
    protected void LinKHref_Click(object sender, EventArgs e)
    {
        string arge = ((LinkButton)sender).CommandName;
        switch (arge)
        {
            case "博客首页":

                break;
            case "给我留言":
                Response.Redirect("Message.aspx?name=" + hidname.Value + "&&msgid=0&&userid=" + hiduserid.Value);
                break;
            case "博客相册":
                Response.Redirect("Photo.aspx?name=" + hidname.Value + "&&userid=" + hiduserid.Value);
                break;
            case "文章管理":
                Response.Redirect("ArictleAll.aspx?name=" + hidname.Value + "&&userid=" + hiduserid.Value);
                break;
            case "信息管理":
                Response.Redirect("PictureManagement.aspx?name=" + hidname.Value + "&&userid=" + hiduserid.Value);
                break;
            case "评论管理":
                Response.Redirect("Discuss.aspx?name=" + hidname.Value + "&&userid=" + hiduserid.Value);
                break;
            default:
                break;
        }
    }
    protected void repArictle_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName == "_title")
        {
            Label lblogkindid = (Label)repArictle.Items[e.Item.ItemIndex].FindControl("lblogkindid");
            Label lbuserid = (Label)repArictle.Items[e.Item.ItemIndex].FindControl("lbuserid");
            Response.Redirect("ArictleAll.aspx?name="+hidname.Value+"&&userid=" + hiduserid.Value+"&&loguserid="+lbuserid.Text+"&&logkindid="+lblogkindid.Text);
        }
    }
}
