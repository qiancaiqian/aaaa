﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Collections.Generic;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Model;
using BLL;

public partial class ArticleManagement : System.Web.UI.Page
{
    private ArticleManagementBLL ab = null;
    private  List<LogView> lv = null;
    private  List<LogKind> lk = null;
    public ArticleManagement() 
    { 
        ab = new ArticleManagementBLL();
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Request["userid"]!=null)
            {
                hiduserid.Value = Request["userid"].ToString();
            }
            if (hiduserid.Value=="0")
            {
                Page.ClientScript.RegisterClientScriptBlock(Page.GetType(), "key", "alert('游客无法新增文章分类')", true);
                return;
            }
            if (Request["name"] != null)
            {
                hidname.Value = Request["name"].ToString();
            }
            else
            {
                hidname.Value = "youke";
            }
            BindLoKinds(Convert.ToInt32(hiduserid.Value));//绑定日志分类内容
        } 
    }


    private void BindLoKinds(int userid)
    {
        lk = ab.GetAllKind(new LogKind(userid));
        givLogsKind.DataSource = lk;
        givLogsKind.DataBind();
    }


    protected void btnActicle_Click(object sender, EventArgs e)
    {
        BindLoKinds(Convert.ToInt32(hiduserid.Value));
        string arge = ((Button)sender).Text;
        if (string.IsNullOrEmpty(txtkind.Text))
        {
            Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "key", "alert('分类名称不能为空!')", true);
            return;
        }
        List<string> lname = new List<string>();
        int count = 0;
        if (lk!=null)
        {
            count = lk.Count;
        }
        if (count>=10)
        {
            Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "key", "alert('文章类别已经达到上限!')", true);
            return;
        }
        else if (ab.GetAllKind(lk,txtkind.Text))
        {
            Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "key", "alert('此文章分类已经存在!')", true);
            return;
        }
        if (arge=="添加")
        {

            if (!ab.InsertLogKind(new LogKind(Convert.ToInt32(hiduserid.Value), txtkind.Text)))
            {
                Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "key", "alert('添加失败!')", true);
            }
            else
            {
                Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "key", "alert('添加成功!')", true);
            }
        }
        else if (arge=="更新")
        {
            if (!ab.UpdateLogKind(new LogKind(Convert.ToInt32(hiduserid.Value), Convert.ToInt32(lbkindid.Text), txtkind.Text)))
            {
                Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "key", "alert('更新失败!')", true);
            }
            else
            {
                Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "key", "alert('更新成功!')", true);
            }
            btnActicle.Text = "添加";
        }
        BindLoKinds(Convert.ToInt32(hiduserid.Value));
    }
    protected void givLogsKind_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        string comm = e.CommandName;
        //LinkButton lin = (LinkButton)e;
        //string ids = lin.ClientID;
        //int userid = Convert.ToInt32(hiduserid.Value);
        GridViewRow row = (GridViewRow)(((LinkButton)e.CommandSource)).Parent.Parent;
        int index = row.RowIndex;
        if (comm=="_edit")//编辑
        {
            txtkind.Text = ((Label)givLogsKind.Rows[index].Cells[1].FindControl("lbkind")).Text;
            lbkindid.Text = ((Label)givLogsKind.Rows[index].Cells[1].FindControl("lbacticlekind")).Text;
            btnActicle.Text = "更新";
        }
        else if (comm=="_del")//删除
        {
            int id = Convert.ToInt32(((Label)givLogsKind.Rows[index].Cells[1].FindControl("lbacticlekind")).Text);
            string kind=((Label)givLogsKind.Rows[index].Cells[1].FindControl("lbacticlekind")).Text;
            if (!ab.DeleteLogKind(new LogKind(Convert.ToInt32(hiduserid.Value), id, kind)))
            {
                Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "key", "alert('删除失败!')", true);
            }
            else
            {
                Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "key", "alert('删除成功!')", true);
            }
        }
        else
        {

        }
        BindLoKinds(Convert.ToInt32(hiduserid.Value));
    }

    protected void LiBackActile_Click(object sender, EventArgs e)
    {
        Response.Redirect("Arictle.aspx?logkindid=0&&name=" + hidname.Value + "&&loguserid=0&&userid=" + hiduserid.Value);
    }
    protected void LiBackHome_Click(object sender, EventArgs e)
    {
        Response.Redirect("Home.aspx?name=" + hidname.Value + "&&userid=" + hiduserid.Value);
    }
}
