﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class diguiqiuzhi : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        int start = 0;
        int end =1;
        int result = 0;
        result = GetMath1(start, end, Convert.ToInt32(TextBox1.Text));
        Label1.Text = result.ToString();
    }
    private int count=0;
    private int GetMath(int start, int end,int length)
    {
        int result = 0;
        int result_start = 0;
        result = start;
        start = end;
        end = result;        
        end = start + end;
        if (count== length-1)
        {
            result_start = start;
            count= -1;
        }
        else
        {
            count++;
            result_start=GetMath(start, end, length);
            if (count==length-1)
            {
                result = end;
                end = start + end;
                start = result;
                result_start = start;
            }
            else
            {

            }
            count++;
        }
        return result_start;
    }
    
    private int GetMath1(int start, int end, int length)
    {
        int result = 0;
        int result_start = 0;
        if (count==-1)
        {
            result_start = start;
            return result_start;
        }
        result = start;
        start = end;
        end = result;
        end = start + end;
        if (count == length-1)
        {
            result_start = start;
            count= -2;
        } 
        count++;
        result_start = GetMath1(start, end, length);
        return result_start;
    }
}
