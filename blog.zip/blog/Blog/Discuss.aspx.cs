﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Model;
using BLL;

public partial class Discuss : System.Web.UI.Page
{
    private DiscussBll db = new DiscussBll();
    private DataTable author = new DataTable();
    private DataTable ping = new DataTable();
    private DataTable _ping = new DataTable();
    private DataTable user = new DataTable();
    private bool jiou = false;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            hiduserid.Value = Request["userid"].ToString();
            if (Request["name"] != null)
            {
                hidname.Value = Request["name"].ToString();
            }
            else
            {
                hidname.Value = "youke";
            }
            string _name = hidname.Value == "youke" ? "游客" : hidname.Value;
            Label2.Text = "当前用户:" + _name;
            BindPic();
        }
    }
    private void BindPic()
    {
        DataSet ds = db.GetDiscuss(new Model.Discuss(-1, -1));
        author = ds.Tables[0];
        ping = ds.Tables[1];
        user = ds.Tables[2];
        if (author.Rows.Count == 0)
        {
            repPic.Visible = false;
        }
        else
        {
            repPic.Visible = true;
            repPic.DataSource = author;
            repPic.DataBind();
        }
    }
    protected void repPic_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        int index = e.Item.ItemIndex;
        TextBox txtcontenct = null;
        Button btnsumbit = null;
        Label lbkindid = null;
        if (e.CommandName=="_ping")
        {
            BindPic();
            txtcontenct = (TextBox)repPic.Items[index].FindControl("txtcontenct");
            btnsumbit = (Button)repPic.Items[index].FindControl("btnsumbit");
            lbkindid = (Label)repPic.Items[index].FindControl("lbkindid");
            txtcontenct.Visible = !txtcontenct.Visible;
            btnsumbit.Visible = !btnsumbit.Visible;
            hidpingkindid.Value = lbkindid.Text;
        }
        else if (e.CommandName=="fabiao")
        {
            Model.Discuss dis = new Model.Discuss();
            dis.logkindid = Convert.ToInt32(hidpingkindid.Value);
            dis.pinguserid=Convert.ToInt32(hiduserid.Value);
            dis.pingdate=DateTime.Now;
            bool zan=false;
            string contenct=((TextBox)repPic.Items[index].FindControl("txtcontenct")).Text;
            if (db.ExitDicuss_Zan(dis.logkindid,dis.pinguserid))//判断当前用户是否评论了当条文章
            {
                dis = db.GetDiscuss(dis.logkindid, dis.pinguserid);
                dis.pingcontenct = contenct;
                db.UpdateDisscuss_zan(dis);
            }
            else
            {
                dis.zan = zan;
                dis.pingcontenct = contenct;
                db.InsertDiscuss_Zan(dis);
            }
            BindPic();
        }
        else if (e.CommandName=="_zan")
        {
            lbkindid = (Label)repPic.Items[index].FindControl("lbkindid");
            hidpingkindid.Value = lbkindid.Text;
            Model.Discuss dis = new Model.Discuss();
            dis.logkindid = Convert.ToInt32(hidpingkindid.Value);
            dis.pinguserid = Convert.ToInt32(hiduserid.Value);
            dis.pingdate = DateTime.Now;
            bool zan = true;
            //lipingzancount = (LinkButton)repPic.Items[index].FindControl("lipingzancount");
            string contenct = ((TextBox)repPic.Items[index].FindControl("txtcontenct")).Text;
            if (db.ExitDicuss_Zan(dis.logkindid, dis.pinguserid))//判断当前用户是否评论了当条文章
            {
                dis = db.GetDiscuss(dis.logkindid, dis.pinguserid);
                contenct = dis.pingcontenct;
                dis.zan = !dis.zan;
                dis.pingcontenct = contenct;
                db.UpdateDisscuss_zan(dis);
            }
            else
            {
                dis.zan = zan;
                dis.pingcontenct = contenct;
                db.InsertDiscuss_Zan(dis);
            }
            BindPic();
        }
        
    }
    protected void reppinglun_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        Label lbpingdate = null;//评论发表时间
        Label lbpingname = null;//评论者姓名
        TextBox txtpingcontenct = null;//评论内容
        Label lbkindid = null;
        LinkButton lidel = null;
        if (e.Item.ItemType == ListItemType.Header)
        {

        }
        else if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)//奇偶行
        {
            string pingcontenct = _ping.Rows[e.Item.ItemIndex]["pingcontenct"].ToString();
            lbpingdate = (Label)e.Item.FindControl("lbpingdate");
            lbpingname = (Label)e.Item.FindControl("lbpingname");
            lidel = (LinkButton)e.Item.FindControl("lidel");
            txtpingcontenct = (TextBox)e.Item.FindControl("txtpingcontenct");
            int pinguserid = Convert.ToInt32(_ping.Rows[e.Item.ItemIndex]["pinguserid"]);
            DataRow dr = db.GetAuthor(user, pinguserid);//当条日志信息对应的作者信息
            lbpingdate.Text = _ping.Rows[e.Item.ItemIndex]["pingdate"].ToString();
            lbkindid = (Label)e.Item.FindControl("lbkindid");
            if (hiduserid.Value=="0")
            {
                lidel.Enabled = false;
            }
            else
            {
                lidel.Enabled = true;
            }
            if (pinguserid ==0)
            {
                lbpingname.Text = "youke";
                lbpingname.ForeColor = System.Drawing.Color.Gray;
            }
            else
            {
                if (dr == null)
                {
                    lbpingname.Text = "此用户已删除";
                    lbpingname.Attributes.Add("style", "color:#999999");
                    lbpingname.Text = pinguserid == 0 ? "youke" :"此用户已删除";
                }
                else
                {
                    lbpingname.Text = dr["name"].ToString();
                    lbpingname.Text = pinguserid == 0 ? "youke" : dr["name"].ToString();
                    lbpingname.Attributes.Add("style", "color:red");
                }
            }
            
            lbkindid.Text = _ping.Rows[e.Item.ItemIndex]["id"].ToString();
            txtpingcontenct.Text = pingcontenct;
            int line = 0;
            if (txtpingcontenct.Text.Length >= 36)
            {
                char[] ch = txtpingcontenct.Text.ToCharArray();
                string msg = "";
                for (int i = 0; i < ch.Length; i++)
                {
                    msg += ch[i].ToString();
                    if (msg.Trim().Replace("\r\n", "").Length % 35 == 0)
                    {
                        line++;
                        msg += "\r\n";
                    }
                }
                txtpingcontenct.Text = msg;
            }
            txtpingcontenct.BorderStyle = BorderStyle.None;
            if (line == 0)//单行
            {
                if (jiou)//偶数行
                {
                    txtpingcontenct.BackColor = System.Drawing.Color.FromName("#fff0f5");
                    txtpingcontenct.Attributes.Add("style", "overflow:hidden");
                    
                }
                else
                {
                    txtpingcontenct.BackColor = System.Drawing.Color.FromName("#f0ffff");
                    txtpingcontenct.Attributes.Add("style", "overflow:hidden");
                }
                txtpingcontenct.BorderStyle = BorderStyle.None;
            }
            else
            {
                if (jiou)//偶数行
                {
                    txtpingcontenct.BackColor = System.Drawing.Color.FromName("#fff0f5");
                    txtpingcontenct.Attributes.Add("style", "overflow-x:hidden;overflow-y:auto");
                }
                else
                {
                    txtpingcontenct.BackColor = System.Drawing.Color.FromName("#f0ffff");
                    txtpingcontenct.Attributes.Add("style", "overflow-x:hidden;overflow-y:auto");
                }
            }
            line = (line + 1) * 15;
            txtpingcontenct.Height = new Unit(line);
        }
    }
    
    protected void reppinglun_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        int index = e.Item.ItemIndex;
        Label lbkindid = null;
        if (e.CommandName=="_hui")
        {
            lbkindid = (Label)e.Item.FindControl("lbkindid");
            BindPic();
        }
        else if (e.CommandName=="_del")
        {
            lbkindid = (Label)e.Item.FindControl("lbkindid");
            db.DeleteDiscuss(Convert.ToInt32(lbkindid.Text));
            BindPic();
        }
    }
    protected void repPic_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        Label lbauthordate = null;//日志发表时间
        Label lbauthorname = null;//日志作者姓名
        Label lbauthortitle = null;//日志标题
        Label lbkindid = null;
        LinkButton lipingcount = null;//zancount
        LinkButton lipingzancount = null;
        TextBox txtcontenct = null;
        Button btnsumbit = null;
        Repeater rep = null;
        jiou = false;
        if (e.Item.ItemType == ListItemType.Item||e.Item.ItemType == ListItemType.AlternatingItem)//奇数行
        {
            lbauthordate = (Label)e.Item.FindControl("lbauthordate");
            lbauthorname = (Label)e.Item.FindControl("lbauthorname");
            lbauthortitle = (Label)e.Item.FindControl("lbauthortitle");
            lbkindid = (Label)e.Item.FindControl("lbkindid");
            lipingcount = (LinkButton)e.Item.FindControl("lipingcount");
            lipingzancount = (LinkButton)e.Item.FindControl("lipingzancount");
            txtcontenct = (TextBox)e.Item.FindControl("txtcontenct");
            btnsumbit = (Button)e.Item.FindControl("btnsumbit");
            lbauthordate.Text = author.Rows[e.Item.ItemIndex]["logdate"].ToString();
            DataRow dr = db.GetAuthor(user, Convert.ToInt32(author.Rows[e.Item.ItemIndex]["userid"]));//当条日志信息对应的作者信息
            if (dr==null)
            {
                lbauthorname.Text = "此用户已删除";
                lbauthorname.Attributes.Add("style", "color:#999999");

            }
            else
            {
                lbauthorname.Text = dr["name"].ToString();
                lbauthorname.Attributes.Add("style", "color:red");
            }
            lbauthortitle.Text = author.Rows[e.Item.ItemIndex]["logtitle"].ToString();
            lbkindid.Text = author.Rows[e.Item.ItemIndex]["logkindid"].ToString();//日志编号
            if (lbauthortitle.Text.Length>=16)
            {
                char[] ch = lbauthortitle.Text.ToCharArray();
                string msg = "";
                for (int i = 0; i < ch.Length; i++)
                {
                    msg += ch[i].ToString();
                    if (msg.Length>=12)
                    {
                        msg += "\r\n";
                    }
                }
                lbauthortitle.Text = msg;
            }
            if (e.Item.ItemType == ListItemType.AlternatingItem)//偶数行
            {
                jiou = true;
            }
            //HtmlTableRow tr = (HtmlTableRow)e.Item.FindControl("trcontenct");
            //tr.Attributes.Add("style", "display:none");
            Control c= txtcontenct.Parent;
            btnsumbit.Visible = false;
            txtcontenct.Visible = false;
            rep = (Repeater)e.Item.FindControl("reppinglun");
            _ping = db.GetPing(ping, Convert.ToInt32(author.Rows[e.Item.ItemIndex]["logkindid"]));
            if (_ping.Rows.Count == 0)
            {
                lipingcount.Text = "评论(0)";
                lipingzancount.Text = "赞(0)";
                rep.Visible = false;
            }
            else
            {
                rep.Visible = true;
                lipingcount.Text = "评论(" + _ping.Rows.Count.ToString() + ")";
                lipingzancount.Text = "赞(" + _ping.Rows[0]["zancount"].ToString() + ")";
                rep.DataSource = _ping;
                rep.DataBind();
            }
        }
    }

    protected void liBackHome_Click(object sender, EventArgs e)
    {
        Response.Redirect("Home.aspx?name=" + hidname.Value + "&&userid=" + hiduserid.Value);
    }
}
