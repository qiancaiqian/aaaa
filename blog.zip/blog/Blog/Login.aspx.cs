﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Model;
using BLL;
using ShareLibrary;


public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            hiduserid.Value = "0";
            if (Request["name"]==null)//从主页登录
            {
                hidname.Value = "youke";
            }

            else//从注册处登录
            {
                txtname.Text = Request["name"].ToString();
                hidname.Value = txtname.Text;
            }            
            if (Request["userid"]!=null)
            {
                hiduserid.Value = Request["userid"].ToString();
            }
            else
            {
                hiduserid.Value = "0";
            }
        }
    }
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        if (string.IsNullOrEmpty(txtname.Text))
        {
            Page.ClientScript.RegisterClientScriptBlock(Page.GetType(), "key", "alert('用户名不能为空')", true);
            return;
        }
        else if (string.IsNullOrEmpty(txtpwd.Text))
        {
            Page.ClientScript.RegisterClientScriptBlock(Page.GetType(), "key", "alert('密码不能为空')", true);
            return;
        }
        else
        {
            UserBLL ub = new UserBLL();
            user u = ub.CheckUser(txtname.Text, txtpwd.Text);
            if (u.userid != 0 && u.pwd == txtpwd.Text)
            {
                hiduserid.Value = u.userid.ToString();
                Response.Redirect("Home.aspx?userid=" + u.userid + "&&name=" + u.name);
            }
            else
            {
                Page.ClientScript.RegisterClientScriptBlock(Page.GetType(), "key", "alert('密码不对')", true);
            }
        }
    }
    protected void LiBackHome_Click(object sender, EventArgs e)
    {
        Response.Redirect("Home.aspx?name="+hidname.Value+"&&userid="+hiduserid.Value);
    }
}
