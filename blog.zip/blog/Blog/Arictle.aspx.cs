﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using BLL;
using System.Collections.Generic;
using Model;

public partial class Arictle : System.Web.UI.Page
{
    private ArticleManagementBLL ab = null;
    private  List<LogView> lv = null;
    private static int _loguserid = 0;
    public Arictle() 
    { 
        ab = new ArticleManagementBLL();
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            hiduserid.Value = Request["userid"].ToString();
            logkindid.Text = Request["logkindid"].ToString();
            _loguserid = Convert.ToInt32(Request["loguserid"].ToString());
            drpkind1.Visible = false;
            if (Request["name"]!=null)
            {
                hidname.Value = Request["name"].ToString();
            }
            else
            {
                hidname.Value = "游客";
            }
            if (logkindid.Text == "0")
            {
                lbtitle.Text = "发表文章";
                txtArticleContenct.CssClass = "text1";
                txtctiletitle.CssClass = "texttitle1";
                Panel1.Visible = true;
                Panel2.Visible = false;
                BindDropKind(drpkind,ab.GetAllDrop(new LogKind(Convert.ToInt32(hiduserid.Value))));//绑定日志类别下拉框
            }
            else
            {
                DiscussBll db = new DiscussBll();
                logid.Text = Request["logid"].ToString();
                int count = db.GetDiscussCount(Convert.ToInt32(logkindid.Text));
                lbpinglun.Text = "|评论("+count.ToString()+")|";
                if (hiduserid.Value =="0")//一般用户
                {
                    DropDownList1.Visible = false;
                    txtArticleContenct.ReadOnly = true;
                    txtctiletitle.ReadOnly = true;
                }
                else
                {
                    DropDownList1.Visible = true;
                    txtArticleContenct.ReadOnly = false;
                    txtctiletitle.ReadOnly = false;
                }
                Panel1.Visible = false;
                Panel2.Visible = true;
                lv = ab.GetLogView(_loguserid, Convert.ToInt32(logid.Text));
                txtArticleContenct.CssClass = "text";
                txtctiletitle.CssClass = "texttitle";
                lbtitle.Text = "浏览文章";
                txtctiletitle.Text = lv[0].logtitle;
                lbdate.ToolTip = lv[0].logdate.ToString();
                lbdate.Text = Convert.ToDateTime(lbdate.ToolTip).ToString("yyy-MM-dd");
                lbkind.Text = lv[0].logkind;
                txtArticleContenct.Text = lv[0].logcontenct;
                logid.Text = lv[0].logid.ToString();
                drpkind1.SelectedValue = lv[0].logkindid.ToString();
                BindDropKind(drpkind1,ab.GetAllDrop(new LogKind(_loguserid)));//绑定日志类别下拉框
            }
            
        } 
    }
    private void BindDropKind(DropDownList drpkind,int userid)
    {
        drpkind.DataSource = ab.GetAllDrop(new LogKind(userid));
        drpkind.DataTextField = "logkind";
        drpkind.DataValueField = "logkindid";
        drpkind.DataBind();
        drpkind.SelectedValue = "-1";
    }
    private void BindDropKind(DropDownList drpkind,List<LogKind> lo)
    {
        drpkind.DataSource = lo;
        drpkind.DataTextField = "logkind";
        drpkind.DataValueField = "logkindid";
        drpkind.DataBind();
        drpkind.SelectedValue = "-1";
    }
   
    protected void btnfabiao_Click(object sender, EventArgs e)
    {
        lbmessageManage.Text = "";
        if (string.IsNullOrEmpty(txtarticletitle.Text))//文章标题为空
        {
            lbmessageManage.Text = "文章标题为空";
            return;
        }
        int logkindid = Convert.ToInt32(drpkind.SelectedValue);
        if (logkindid == -1)
        {
            lbmessageManage.Text = "请选择文章类型";
            return;
        }
        LogView lvi = new LogView(_loguserid, logkindid);
        lvi.logtitle = txtarticletitle.Text;
        lvi.logcontenct = txtArticleContenct.Text;
        if (ab.InsertLogView(lvi))
        {
            lbmessageManage.Text = "文章发表成功!";
            Response.Redirect("ArictleAll.aspx?name="+hidname.Value+"&&userid=" + hiduserid.Value);
        }
        else
        {
            lbmessageManage.Text = "文章发表失败!";
        }
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        drpkind1.Visible = false;
        lbkind.Visible = true;
        switch (DropDownList1.SelectedIndex)
        {
            case 2:
                if (TextLength(txtctiletitle.Text, 20) && TextLength(txtArticleContenct.Text, 2000))
                {
                    LogView lvi = new LogView(_loguserid, Convert.ToInt32(logkindid.Text));
                    lvi.logtitle = txtctiletitle.Text;
                    lvi.logcontenct = txtArticleContenct.Text;
                    lvi.logid = Convert.ToInt32(logid.Text);
                    ab.UpdateLogView(lvi);
                    Response.Redirect("ArictleAll.aspx?name="+hidname.Value+"&&userid="+hiduserid.Value);
                }
                else
                {
                    lbmessageManage.Text = "标题长度需小于20，正文长度需小于2000";
                    DropDownList1.SelectedIndex = 0;
                }
                break;
            case 1:
                    Response.Redirect("ArictleAll.aspx?name="+hidname.Value+"&&userid=" + hiduserid.Value);
                break;
            case 3:
                ab.DeleteLogView(Convert.ToInt32(logid.Text));
                Response.Redirect("ArictleAll.aspx?name="+hidname.Value+"&&userid="+hiduserid.Value);
                break;
            case 4:
                drpkind1.Visible = true;
                drpkind1.SelectedValue = logkindid.Text;
                lbkind.Visible = false;
                break;
            case 5:

                break;
            case 6:

                break;
            default:
                break;
        }
        
    }
    private bool TextLength(string msg, int length)
    {
        if (msg.Length>=length)
        {
            return false;
        }
        else
        {
            return true;
        }
    }
    protected void drpkind1_SelectedIndexChanged(object sender, EventArgs e)
    {
        lbkind.Visible = true;
        lbkindid.Text = drpkind1.SelectedValue;
        if (TextLength(txtarticletitle.Text, 20) && TextLength(txtArticleContenct.Text, 2000))
        {
            LogView lvi = new LogView(_loguserid, Convert.ToInt32(lbkindid.Text));
            lvi.logtitle = txtctiletitle.Text;
            lvi.logcontenct = txtArticleContenct.Text;
            lvi.logid = Convert.ToInt32(logid.Text);
            ab.UpdateLogView(lvi);
            lbkind.Text = drpkind1.SelectedItem.Text;
            drpkind1.Visible = false;
            Response.Redirect("ArictleAll.aspx?name="+hidname.Value+"&&userid="+hiduserid.Value);
        }
        else
        {
            lbmessageManage.Text = "标题长度需小于20，正文长度需小于2000";
            DropDownList1.SelectedIndex = 0;
        }
    }
    protected void btnKind_Click(object sender, EventArgs e)
    {
        Response.Redirect("ArticleManagement.aspx?name="+hidname.Value+"&&userid="+hiduserid.Value);
    }
    protected void LiBackHome_Click(object sender, EventArgs e)
    {
        UserBLL ub = new UserBLL();
        string name = ub.GetSingleUsers(Convert.ToInt32(hiduserid.Value)).name;
        Response.Redirect("Home.aspx?name="+name+"&&userid="+hiduserid.Value);
    }
}
