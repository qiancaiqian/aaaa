﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Model;
using BLL;

public partial class Message : System.Web.UI.Page
{
    private MessageBLL mb = null;
    public Message() { mb = new MessageBLL(); }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            hiduserid.Value =Request["userid"].ToString();
            hidmsgid.Value = Request["msgid"].ToString();
            if (hidmsgid.Value != "0")//管理员
            {
                Model.Message m = mb.GetSingleMessage(Convert.ToInt32(hidmsgid.Value));
                TextBox1.Text = m.msgusername;
                TextBox2.Text = m.msg;
                Button1.Text = "更新";
            }
            else
            {
                btnDelete.Visible = false;
            }
            if (Request["name"] != null)
            {
                hidname.Value = Request["name"].ToString();
            }
            else
            {
                hidname.Value = "youke";
            }
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Model.Message ms = new Model.Message();
        if (TextBox2.Text == "")
        {
            Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "key", "alert('留言内容不能为空')", true);
            return;
        }
        else if (TextBox1.Text == "")
        {
            Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "key", "alert('请留下你的大名')", true);
            return;
        }
        ms.msguserid = Convert.ToInt32(hiduserid.Value);
        ms.msg = TextBox2.Text;
        ms.msgdate = DateTime.Now;
        ms.msgusername = TextBox1.Text;
        ms.msgid =Convert.ToInt32(hidmsgid.Value);
        if (Button1.Text=="提交")
        {
            mb.InsertMessage(ms);
            Response.Redirect("Home.aspx?name="+hidname.Value+"&&userid=" + hiduserid.Value);
        }
        else
        {
            mb.UpdateMessage(ms);
            Response.Redirect("Home.aspx?name=" + hidname.Value + "&&userid=" + hiduserid.Value);
        }
    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        mb.DeleteMessage(Convert.ToInt32(hidmsgid.Value));
        Response.Redirect("Home.aspx?name=" + hidname.Value + "&&userid=" + hiduserid.Value);
    }

    protected void liBackHome_Click(object sender, EventArgs e)
    {
        Response.Redirect("Home.aspx?name=" + hidname.Value + "&&userid=" + hiduserid.Value);
    }
}
