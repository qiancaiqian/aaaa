﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Model;
using BLL;
using ShareLibrary;
using System.Collections.Generic;
using System.IO;

public partial class Photo : System.Web.UI.Page
{
    private PhotoBLL pb = new PhotoBLL();
    private Picture p = new Picture();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            hiduserid.Value = Request["userid"].ToString();
            BindPicture(Convert.ToInt32(hiduserid.Value));
            if (hiduserid.Value=="0")
            {
                Panel7.Visible = false;
            }
            else
            {
                Panel7.Visible = true;
            }
            if (Request["name"] != null)
            {
                hidname.Value = Request["name"].ToString();
            }
            else
            {
                hidname.Value = "youke";
                
            }
            string _name=hidname.Value=="youke"?"游客":hidname.Value;
            Label2.Text = "当前用户:" + _name;
        }
    }

    protected void btnOK_Click(object sender, EventArgs e)
    {
        Model.Photo ph = new Model.Photo();
        bool s = false;
        string[] pictures = p.SavePicture("images/maps/", filPicture);
        ph.photouserid = Convert.ToInt32(hiduserid.Value);
        ph.photomapsrc = pictures[0];
        string _map = "";
        ph.photodescription = txtdescription.Text;
        if (ph.photomapsrc != "")
        {
            //_map=ph.photomapsrc;
            ph.photomapsrc = p.SmallPic(ph.photomapsrc, "images/maps/",180,180);
            s = true;
        }
        if (btnOK.Text=="确定")
        {
            if (s)
            {
                
                if (pb.InsertPhoto(ph))
                {
                    BindPicture(ph.photouserid);
                    
                }
            }
            else
            {
                Page.ClientScript.RegisterClientScriptBlock(Page.GetType(), "key", "alert('未上传图片')", true);
            }
        }
        else
        {
            ph.id = Convert.ToInt32(hidphotoid.Value);
            if (!s)
            {
                Model.Photo _p = pb.GetPhoto(ph.id);
                ph.photomapsrc = _p.photomapsrc;
            }
            if (pb.UpdatePhoto(ph))
            {
                BindPicture(ph.photouserid);
            }
            btnOK.Text = "确定";
        }
        txtdescription.Text = "";
    }
    private List<Model.Photo> lp = null;
    private void BindPicture(int userid)
    {
        lp = pb.GetPhotoS(userid);
        if (lp.Count == 0)
        {
            repPicture.Visible = false;
        }
        else
        {
            repPicture.Visible = true;
            repPicture.DataSource = lp;
            repPicture.DataBind();
        }
    }
    protected void repPicture_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        bool s = false;
        Label photoid = null;
        #region
        if (e.CommandName=="_edit")
        {
            photoid = (Label)e.Item.FindControl("lbid");
        } 
        else if (e.CommandName == "_edit1")
        {
            photoid = (Label)e.Item.FindControl("lbid1");
        }
        else if (e.CommandName == "_edit2")
        {
            photoid = (Label)e.Item.FindControl("lbid2");
        }
        else if (e.CommandName == "_edit3")
        {
            photoid = (Label)e.Item.FindControl("lbid3");
        }
        else if (e.CommandName == "_edit4")
        {
            photoid = (Label)e.Item.FindControl("lbid4");
        }
        else if (e.CommandName == "_del")
        {
            photoid = (Label)e.Item.FindControl("lbid");
            s = true;
        }
        else if (e.CommandName == "_del1")
        {
            photoid = (Label)e.Item.FindControl("lbid1");
        }
        else if (e.CommandName == "_del2")
        {
            photoid = (Label)e.Item.FindControl("lbid2");
            s = true;
        }
        else if (e.CommandName == "_del3")
        {
            photoid = (Label)e.Item.FindControl("lbid3");
            s = true;
        }
        else if (e.CommandName == "_del4")
        {
            photoid = (Label)e.Item.FindControl("lbid4");
            s = true;
        }
        #endregion
        if (photoid!=null)
        {
            hidphotoid.Value = photoid.Text;
            int id = Convert.ToInt32(photoid.Text);
            if (s)
            {
                pb.DeletePhoto(id);
                BindPicture(Convert.ToInt32(hiduserid.Value));
            }
            else
            {
                Model.Photo _p = pb.GetPhoto(id);
                txtdescription.Text = _p.photodescription;
                btnOK.Text = "更新";
            }
        }
    }
    protected void repPicture_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        Label lbid = null, lbid1 = null, lbid2 = null, lbid3 = null, lbid4 = null;
        Label lbdate = null, lbdate1 = null, lbdate2 = null, lbdate3 = null, lbdate4 = null;
        Label lbdescription = null, lbdescription1 = null, lbdescription2 = null, lbdescription3 = null, lbdescription4 = null;
        Image Image=null,Image1 = null, Image2 = null, Image3 = null, Image4 = null;
        Model.Photo po = null, po1 = null, po2 = null, po3 = null, po4 = null;
        Button btnEdit = null, btnEdit1 = null, btnEdit2 = null, btnEdit3 = null, btnEdit4 = null;
        Button btnDel = null, btnDel1 = null, btnDel2 = null, btnDel3 = null, btnDel4 = null;
        Panel Panel1 = null, Panel2 = null, Panel3 = null, Panel4 = null, Panel5 = null;
        if (e.Item.ItemType==ListItemType.Item||e.Item.ItemType==ListItemType.AlternatingItem)
        {
            #region
            lbid = (Label)e.Item.FindControl("lbid");
            lbid1 = (Label)e.Item.FindControl("lbid1");
            lbid2= (Label)e.Item.FindControl("lbid2");
            lbid3 = (Label)e.Item.FindControl("lbid3");
            lbid4 = (Label)e.Item.FindControl("lbid4");
            lbdate = (Label)e.Item.FindControl("lbdate");
            lbdate1 = (Label)e.Item.FindControl("lbdate1");
            lbdate2 = (Label)e.Item.FindControl("lbdate2");
            lbdate3 = (Label)e.Item.FindControl("lbdate3");
            lbdate4 = (Label)e.Item.FindControl("lbdate4");
            lbdescription = (Label)e.Item.FindControl("lbdescription");
            lbdescription1= (Label)e.Item.FindControl("lbdescription1");
            lbdescription2 = (Label)e.Item.FindControl("lbdescription2");
            lbdescription3 = (Label)e.Item.FindControl("lbdescription3");
            lbdescription4 = (Label)e.Item.FindControl("lbdescription4");
            Image = (Image)e.Item.FindControl("Image");
            Image1 = (Image)e.Item.FindControl("Image1");
            Image2 = (Image)e.Item.FindControl("Image2");
            Image3 = (Image)e.Item.FindControl("Image3");
            Image4 = (Image)e.Item.FindControl("Image4");
            Panel1 = (Panel)e.Item.FindControl("Panel1");
            Panel2 = (Panel)e.Item.FindControl("Panel2");
            Panel3 = (Panel)e.Item.FindControl("Panel3");
            Panel4 = (Panel)e.Item.FindControl("Panel4");
            Panel5 = (Panel)e.Item.FindControl("Panel5");
            btnEdit=(Button)e.Item.FindControl("btnEdit");
            btnEdit1=(Button)e.Item.FindControl("btnEdit1");
            btnEdit2=(Button)e.Item.FindControl("btnEdit2");
            btnEdit3=(Button)e.Item.FindControl("btnEdit3");
            btnEdit4=(Button)e.Item.FindControl("btnEdit4");
            btnDel=(Button)e.Item.FindControl("btnDel");
            btnDel1=(Button)e.Item.FindControl("btnDel1");
            btnDel2=(Button)e.Item.FindControl("btnDel2");
            btnDel3=(Button)e.Item.FindControl("btnDel3");
            btnDel4=(Button)e.Item.FindControl("btnDel4");
            #endregion
            #region
            if (e.Item.ItemIndex * 5 < lp.Count)
            {
                po=lp[e.Item.ItemIndex*5];
                lbid.Text = po.id.ToString();
                lbdate.Text = po.photodate.ToString("yyy-MM-dd HH:mm:ss");
                lbdescription.Text = po.photodescription;
                Image.ImageUrl = po.photomapsrc;
                Panel1.Visible = true;
            }
            else
            {
                Panel1.Visible = false;
            }
            if (e.Item.ItemIndex*5+1<lp.Count)
            {
                po1 = lp[e.Item.ItemIndex * 5+1];
                lbid1.Text = po1.id.ToString();
                lbdate1.Text = po1.photodate.ToString("yyy-MM-dd HH:mm:ss");
                lbdescription1.Text = po1.photodescription;
                Image1.ImageUrl = po1.photomapsrc;
                Panel2.Visible = true;
            }
            else
            {
                Panel2.Visible = false;
            }
            if (e.Item.ItemIndex * 5 +2 < lp.Count)
            {
                po2 = lp[e.Item.ItemIndex * 5+2];
                lbid2.Text = po2.id.ToString();
                lbdate2.Text = po2.photodate.ToString("yyy-MM-dd HH:mm:ss");
                lbdescription2.Text = po2.photodescription;
                Image2.ImageUrl = po2.photomapsrc;
                Panel3.Visible = true;
            }
            else
            {
                Panel3.Visible = false;
            }
            if (e.Item.ItemIndex * 5 +3 < lp.Count)
            {
                po3 = lp[e.Item.ItemIndex * 5+3];
                lbid3.Text = po3.id.ToString();
                lbdate3.Text = po3.photodate.ToString("yyy-MM-dd HH:mm:ss");
                lbdescription3.Text = po3.photodescription;
                Image3.ImageUrl = po3.photomapsrc;
                Panel4.Visible = true;
            }
            else
            {
                Panel4.Visible = false;
            }
            if (e.Item.ItemIndex * 5 + 4 < lp.Count)
            {
                po4 = lp[e.Item.ItemIndex * 5+4];
                lbid4.Text = po4.id.ToString();
                lbdate4.Text = po4.photodate.ToString("yyy-MM-dd HH:mm:ss");
                lbdescription4.Text = po4.photodescription;
                Image4.ImageUrl = po4.photomapsrc;
                Panel5.Visible = true;
            }
            else
            {
                Panel5.Visible = false;
            }
            #endregion
            if (hiduserid.Value=="0")
            {
                btnEdit.Enabled = false;
                btnEdit1.Enabled = false;
                btnEdit2.Enabled = false;
                btnEdit3.Enabled = false;
                btnEdit4.Enabled = false;
                btnDel.Enabled = false;
                btnDel1.Enabled = false;
                btnDel2.Enabled = false;
                btnDel3.Enabled = false;
                btnDel4.Enabled = false;
            }
            else
            {
                btnEdit.Enabled = true;
                btnEdit1.Enabled = true;
                btnEdit2.Enabled = true;
                btnEdit3.Enabled = true;
                btnEdit4.Enabled = true;
                btnDel.Enabled = true;
                btnDel1.Enabled = true;
                btnDel2.Enabled = true;
                btnDel3.Enabled = true;
                btnDel4.Enabled = true;
            }
        }
    }

    protected void liBackHome_Click(object sender, EventArgs e)
    {
        Response.Redirect("Home.aspx?name=" + hidname.Value + "&&userid=" + hiduserid.Value);
    }
}
