﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Model;
using System.Collections.Generic;
using BLL;
//51aspx
public partial class ArictleAll : System.Web.UI.Page
{
    private ArticleManagementBLL ab = null;
    private List<LogView> lv = null;
    public ArictleAll() 
    { 
        ab = new ArticleManagementBLL();
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            hiduserid.Value = Request["userid"].ToString();
            BindLogs(Convert.ToInt32(hiduserid.Value));//绑定日志文章内容
            if (hiduserid.Value =="0")
            {
                btnfabiao.Enabled = false;
                if (lv.Count==0)
                {
                    Page.ClientScript.RegisterClientScriptBlock(Page.GetType(),"key","alert('尚不存在文章')",true);
                }
            }
            if (Request["name"] != null)
            {
                hidname.Value = Request["name"].ToString();
            }
            else
            {
                hidname.Value = "youke";
            }
        }
    }

    private void BindLogs(int userid)
    {
        lv = ab.GetLogView(userid,0);
        givContenct.DataSource = lv;
        givContenct.DataBind();
    }
    protected void givContenct_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        GridViewRow row = (GridViewRow)(((LinkButton)e.CommandSource)).Parent.Parent;
        int index = row.RowIndex;
        Label lbacticlekind = ((Label)givContenct.Rows[index].Cells[0].FindControl("lbacticlekind"));
        LinkButton LinkButton3 = (LinkButton)givContenct.Rows[index].Cells[5].FindControl("LinkButton3");
        LinkButton LinkButton1 = (LinkButton)givContenct.Rows[index].Cells[6].FindControl("LinkButton1");
        if (e.CommandName == "_del")
        {
            int logid=Convert.ToInt32(((Label)givContenct.Rows[index].Cells[0].FindControl("logid")).Text);
            if (ab.DeleteLogView(logid))
            {
                Page.ClientScript.RegisterClientScriptBlock(Page.GetType(), "key", "alert('删除成功')", true);
                BindLogs(Convert.ToInt32(hiduserid.Value));
            }
            else
            {
                Page.ClientScript.RegisterClientScriptBlock(Page.GetType(), "key", "alert('删除失败!')", true);
            }
        }
    }
    protected void givContenct_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            if (hiduserid.Value=="0")//游客
            {
                e.Row.Cells[7].Enabled = false;
            }
            string dates = e.Row.Cells[4].Text;
            e.Row.Cells[4].ToolTip = Convert.ToDateTime(dates).ToString();
            e.Row.Cells[4].Text = Convert.ToDateTime(dates).ToString("yyy-MM-dd");
            string msg = e.Row.Cells[1].Text;
            if (msg.Length > 9)
            {
                e.Row.Cells[1].ToolTip = msg;
                e.Row.Cells[1].Text = msg.Substring(0, 8) + "...";
            }
            msg = e.Row.Cells[3].Text;
            if (msg.Length > 11)
            {
                e.Row.Cells[3].ToolTip = msg;
                e.Row.Cells[3].Text = msg.Trim().Substring(0, 10) + "...";
            }
        }
    }
    protected void btnfabiao_Click(object sender, EventArgs e)
    {
        Response.Redirect("Arictle.aspx?name="+hidname.Value+"&&logkindid=0&&loguserid=0&&userid=" + hiduserid.Value + "");
    }
    protected void btnBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("Home.aspx?name="+hidname.Value+"&userid=" + hiduserid.Value);
    }
    protected void givContenct_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        givContenct.PageIndex = e.NewPageIndex;
        BindLogs(Convert.ToInt32(hiduserid.Value));
    }
}
