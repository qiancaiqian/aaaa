using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;

namespace DAL
{
    public class Connstring
    {
        protected static string _connstring { get { return ConfigurationManager.ConnectionStrings["MyBlog"].ToString(); } }
    }
}
