using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Model;

namespace DAL
{
    public class PhotoDAL : Connstring
    {
        public int InsertPhoto(Photo p)
        {
            string sql = "insert into Photo(photouserid,photodescription,photomapsrc,photodate) values(@photouserid,@photodescription,@photomapsrc,@photodate)";
            return SqlHelper.ExecuteNonQuery(_connstring, CommandType.Text, sql, new SqlParameter("@photouserid", p.photouserid), new SqlParameter("@photodescription", p.photodescription), new SqlParameter("@photomapsrc", p.photomapsrc), new SqlParameter("@photodate", p.photodate));
        }

        public List<Photo> GetPhoto()
        {
            List<Photo> lp = new List<Photo>();
            string sql = "select * from Photo order by photouserid";
            SqlDataReader sdr = SqlHelper.ExecuteReader(_connstring, CommandType.Text, sql);
            if (sdr!=null)
            {
                while (sdr.Read())
                {
                    Photo p = new Photo();
                    p.id = Convert.ToInt32(sdr["id"]);
                    p.photouserid = Convert.ToInt32(sdr["photouserid"]);
                    p.photodescription = sdr["photodescription"].ToString();
                    p.photomapsrc = sdr["photomapsrc"].ToString();
                    p.photodate = Convert.ToDateTime(sdr["photodate"]);
                    lp.Add(p);
                }

            }
            return lp;
        }

        public Photo GetPhoto(int id)
        {
            Photo p = new Photo();
            string sql = "select * from Photo where id="+id;
            SqlDataReader sdr = SqlHelper.ExecuteReader(_connstring, CommandType.Text, sql);
            if (sdr != null)
            {
                while (sdr.Read())
                {
                   
                    p.id = Convert.ToInt32(sdr["id"]);
                    p.photouserid = Convert.ToInt32(sdr["photouserid"]);
                    p.photodescription = sdr["photodescription"].ToString();
                    p.photomapsrc = sdr["photomapsrc"].ToString();
                    p.photodate = Convert.ToDateTime(sdr["photodate"]);
                }

            }
            return p;
        }

        public int UpdatePhoto(Photo p)
        {
            string sql = "update Photo set photodescription=@photodescription,photomapsrc=@photomapsrc,photodate=@photodate where id=@id";
            return SqlHelper.ExecuteNonQuery(_connstring, CommandType.Text, sql, new SqlParameter("@photodescription", p.photodescription), new SqlParameter("@photomapsrc", p.photomapsrc), new SqlParameter("@photodate", p.photodate), new SqlParameter("@id",p.id));
        }

        public int DeletePhoto(int id)
        {
            string sql = "delete from Photo where id="+id;
            return SqlHelper.ExecuteNonQuery(_connstring, CommandType.Text, sql);
        }
    }
}
