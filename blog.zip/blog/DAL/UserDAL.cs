using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Model;

namespace DAL
{
    public class UserDAL : Connstring
    {

        public int ExitUser(string name)
        {
            string sql = "select count(1) from [user] where name=@name";
            object obj = SqlHelper.ExecuteScalar(_connstring,CommandType.Text,sql,new SqlParameter("@name",name));
            if (obj==null)
            {
                return -1;
            }
            else
            {
                return Convert.ToInt32(obj);
            }
        }
        public user CheckUser(string name)
        {
            string sql = "select * from [user] where name=@name";
            user u = new user();
            bool s = false;
            SqlDataReader sdr = SqlHelper.ExecuteReader(_connstring, CommandType.Text, sql, new SqlParameter("@name", name));
            if (sdr == null)
            {
                return null;
            }
            else
            {
                while (sdr.Read())
                {
                    s = true;
                    u.userid =Convert.ToInt32(sdr["userid"]);
                    u.pwd = sdr["pwd"].ToString();
                    u.name = sdr["name"].ToString();
                    u.relname = sdr["relname"].ToString();
                    u.pic = sdr["pic"].ToString();
                    u.email = sdr["email"].ToString();
                    u.tel = Convert.ToInt32(sdr["tel"]);
                }
                if (!s)
                {
                    u.userid = 0;
                }
                sdr.Close();
                sdr.Dispose();
            }
            return u;
        }
        public int InsertUser(user u)
        {
            string sql = "insert into [user]([name],relname,pwd,pic,email,tel) values(@name,@relname,@pwd,@pic,@email,@tel)";
            object obj = SqlHelper.ExecuteNonQuery(_connstring, CommandType.Text, sql, new SqlParameter("@name", u.name), new SqlParameter("@relname", u.relname), 
                new SqlParameter("@pwd", u.pwd), new SqlParameter("@pic", u.pic),new SqlParameter("@email",u.email),new SqlParameter("@tel",u.tel));
            if (obj==null)
            {
                return 0;
            }
            else
	        {
                return Convert.ToInt32(obj);
	        }
        }

        public int UpdateUser(user u)
        {
            string sql = "update [user] set [name]=@name,relname=@relname,pwd=@pwd,pic=@pic,email=@email,tel=@tel where userid=@userid";
            object obj = SqlHelper.ExecuteNonQuery(_connstring, CommandType.Text, sql, new SqlParameter("@name", u.name), new SqlParameter("@relname", u.relname),
                new SqlParameter("@pwd", u.pwd), new SqlParameter("@pic", u.pic),new SqlParameter("@userid",u.userid),new SqlParameter("@email",u.email),new SqlParameter("@tel",u.tel));
            if (obj == null)
            {
                return 0;
            }
            else
            {
                return Convert.ToInt32(obj);
            }
        }

        public List<user> GetUsers(string kind,string value)
        {
            List<user> lu = new List<user>();
            string sql = "select * from [user]";
            if (kind!="*")
            {
                sql += " where [" + kind + "] like '%" + value + "%'";
            }
            SqlDataReader sdr = SqlHelper.ExecuteReader(_connstring, CommandType.Text, sql);
            if (sdr==null)
            {
                return null;
            }
            else
            {
                while (sdr.Read())
                {
                    user u = new user();
                    u.userid = Convert.ToInt32(sdr["userid"]);
                    u.name = sdr["name"].ToString();
                    u.relname = sdr["relname"].ToString();
                    u.pwd = sdr["pwd"].ToString();
                    u.pic = sdr["pic"].ToString();
                    u.email = sdr["email"].ToString();
                    u.tel = Convert.ToInt32(sdr["tel"]);
                    lu.Add(u);
                }
                sdr.Close();
                sdr.Dispose();
            }
            return lu;
        }

        public List<user> GetUsers()
        {
            List<user> lu = new List<user>();
            string sql = "select * from [user]";
            SqlDataReader sdr = SqlHelper.ExecuteReader(_connstring, CommandType.Text, sql);
            if (sdr == null)
            {
                return null;
            }
            else
            {
                while (sdr.Read())
                {
                    user u = new user();
                    u.userid = Convert.ToInt32(sdr["userid"]);
                    u.name = sdr["name"].ToString();
                    u.relname = sdr["relname"].ToString();
                    u.pwd = sdr["pwd"].ToString();
                    u.pic = sdr["pic"].ToString();
                    u.email = sdr["email"].ToString();
                    u.tel = Convert.ToInt32(sdr["tel"]);
                    lu.Add(u);
                }
                sdr.Close();
                sdr.Dispose();
            }
            return lu;
        }

        public user GetSingleUsers(int userid)
        {
            user u = new user();
            string sql = "select * from [user] where userid="+userid;
            SqlDataReader sdr = SqlHelper.ExecuteReader(_connstring, CommandType.Text, sql);
            if (sdr == null)
            {
                return null;
            }
            else
            {
                while (sdr.Read())
                {
                    
                    u.userid = Convert.ToInt32(sdr["userid"]);
                    u.name = sdr["name"].ToString();
                    u.relname = sdr["relname"].ToString();
                    u.pwd = sdr["pwd"].ToString();
                    u.pic = sdr["pic"].ToString();
                    u.email = sdr["email"].ToString();
                    u.tel = Convert.ToInt32(sdr["tel"]);
                }
                sdr.Close();
                sdr.Dispose();
            }
            return u;
        }

        public int DeleteUser(int userid)
        {
            string sql = "delete from [user] where userid=@userid";
            return SqlHelper.ExecuteNonQuery(_connstring, CommandType.Text, sql, new SqlParameter("@userid", userid));
        }
    }
}
