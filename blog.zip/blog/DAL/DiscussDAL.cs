using System;
using System.Collections.Generic;
using System.Text;
using Model;
using System.Data;
using System.Data.SqlClient;

namespace DAL
{
    public class DiscussDAL:Connstring
    {
        public DataSet GetDiscuss(Discuss dis)
        {
            DataSet ds = new DataSet();
            string sql = "";
            StringBuilder sbl = new StringBuilder();
            sbl.Append("select lk.userid,lv.logkindid,lv.logdate,lv.logtitle,lk.logkind,lv.logcontenct from LogView as lv inner join LogKind as lk on lk.logkindid=lv.logkindid");
            if (dis.userid!=-1)
            {
                sbl.Append(" where lk.userid="+dis.userid);
            }
            sbl.Append(" select d.id,d.logkindid,lk.userid,d.pingdate,d.pinguserid,d.pingcontenct,d.zan,lk.logkind from Discuss as d inner join LogKind as lk on lk.logkindid=d.logkindid order by lk.logkindid");
            sbl.Append(" select * from [user]");
            sql = sbl.ToString();
            ds=SqlHelper.ExecuteDataset(_connstring,CommandType.Text,sql);
            return ds;
        }

        public int ExitDicuss_Zan(int logkindid, int pinguserid)
        {
            string sql = "select count(1) from Discuss where logkindid=@logkindid and pinguserid=@pinguserid";
            return Convert.ToInt32(SqlHelper.ExecuteScalar(_connstring, CommandType.Text, sql,new SqlParameter("@logkindid",logkindid),new SqlParameter("@pinguserid",pinguserid)));
        }
        public int InsertDiscuss_Zan(Discuss dis)
        {
            string sql = "";
            sql = "insert into Discuss(logkindid,pingdate,pinguserid,zan,pingcontenct) values(@logkindid,@pingdate,@pinguserid,@zan,@pingcontenct)";
            return SqlHelper.ExecuteNonQuery(_connstring, CommandType.Text, sql, new SqlParameter("@logkindid", dis.logkindid), new SqlParameter("@pingdate", dis.pingdate), new SqlParameter("@pinguserid", dis.pinguserid), new SqlParameter("@zan", dis.zan),new SqlParameter("@pingcontenct",dis.pingcontenct));

        }
        public Discuss GetDiscuss(int logkindid, int pinguserid)
        {
            string sql = "select * from Discuss where logkindid='"+logkindid+"' and pinguserid='"+pinguserid+"'";
            SqlDataReader sdr = SqlHelper.ExecuteReader(_connstring,CommandType.Text,sql);
            Discuss dis = new Discuss();
            if (sdr!=null)
            {
                while (sdr.Read())
                {
                    dis.logkindid = Convert.ToInt32(sdr["logkindid"]);
                    dis.pingcontenct = sdr["pingcontenct"].ToString();
                    dis.pinguserid = Convert.ToInt32(sdr["pinguserid"]);
                    dis.pingdate = Convert.ToDateTime(sdr["pingdate"]);
                    dis.zan = Convert.ToBoolean(sdr["zan"]);
                    dis.id = Convert.ToInt32(sdr["id"]);
                }
                sdr.Close();
                sdr.Dispose();
            }
            return dis;
        }
        public int UpdateDisscuss_zan(Discuss dis)
        {
            string sql = "update Discuss set pingdate=@pingdate,zan=@zan,pingcontenct=@pingcontenct where id=@id";
            return SqlHelper.ExecuteNonQuery(_connstring, CommandType.Text, sql, new SqlParameter("@pingdate", dis.pingdate), new SqlParameter("@zan", dis.zan), new SqlParameter("@pingcontenct", dis.pingcontenct), new SqlParameter("@id", dis.id));
        }
        public int DeleteDiscuss(int id)
        {
            string sql = "delete from Discuss where id=@id";
            return SqlHelper.ExecuteNonQuery(_connstring, CommandType.Text, sql, new SqlParameter("@id", id));
        }

        public int GetDiscussCount(int logkinid)
        {
            int result = 0;
            string sql = "select count(*) from Discuss where logkindid=@logkindid";
            object obj = SqlHelper.ExecuteScalar(_connstring, CommandType.Text, sql, new SqlParameter("@logkindid", logkinid));
            if (obj!=null)
            {
                result = Convert.ToInt32(obj);
            }
            return result;
        }
    }
}
