using System;
using System.Collections.Generic;
using System.Text;
using Model;
using System.Data.SqlClient;
using System.Data;

namespace DAL
{
   public class ArticleManagementDAL:Connstring
    {
        public int InsertLogView(LogView lo)
        {
            string sql = "insert into [LogView](logtitle,logkindid,logcontenct,logdate) values(@logtitle,@logkind,@logcontenct,@logdate)";
            object obj = SqlHelper.ExecuteNonQuery(_connstring, CommandType.Text, sql, new SqlParameter("@logtitle", lo.logtitle),
                new SqlParameter("@logkind", lo.logkindid), new SqlParameter("@logcontenct", lo.logcontenct),new SqlParameter("@logdate",lo.logdate));
            if (obj == null)
            {
                return 0;
            }
            else
            {
                return Convert.ToInt32(obj);
            }
       }
       public int InsertLogKind(LogKind lk)
       {
           string sql = "insert into [LogKind]([userid],[logkind]) values(@userid,@logkind)";
           object obj = SqlHelper.ExecuteNonQuery(_connstring, CommandType.Text, sql, new SqlParameter("@userid", lk.userid),new SqlParameter("@logkind", lk.logkind));
           if (obj == null)
           {
               return 0;
           }
           else
           {
               return Convert.ToInt32(obj);
           }
       }
       public int UpdateLogKind(LogKind lk)
       {
           string sql = "update [LogKind] set [logkind]=@logkind where logkindid=@logkindid";
           object obj = SqlHelper.ExecuteNonQuery(_connstring, CommandType.Text, sql, new SqlParameter("@logkind", lk.logkind), 
                new SqlParameter("@logkindid", lk.logkindid));
           if (obj == null)
           {
               return 0;
           }
           else
           {
               return Convert.ToInt32(obj);
           }
       }
        public int UpdateLogView(LogView lo)
        {
            string sql = "update [LogView] set logtitle=@logtitle,logkindid=@logkind,logcontenct=@logcontenct,logdate=@logdate where logid=@logid";
            object obj = SqlHelper.ExecuteNonQuery(_connstring, CommandType.Text, sql, new SqlParameter("@logid", lo.logid), new SqlParameter("@logtitle", lo.logtitle),
                new SqlParameter("@logkind", lo.logkindid), new SqlParameter("@logdate", lo.logdate),new SqlParameter("@logcontenct", lo.logcontenct));
            if (obj == null)
            {
                return 0;
            }
            else
            {
                return Convert.ToInt32(obj);
            }
        }


       public int DeleteLogKind(LogKind lk)
       {
           string sql = "delete from [LogKind] where logkindid=@logkindid";
           object obj = SqlHelper.ExecuteNonQuery(_connstring, CommandType.Text, sql, new SqlParameter("@logkindid", lk.logkindid));
           if (obj == null)
           {
               return 0;
           }
           else
           {
               return Convert.ToInt32(obj);
           }
       }
       public int DeleteLogView(int logid)
       {
           string sql = "delete from [LogView] where logid=@logid";
           object obj = SqlHelper.ExecuteNonQuery(_connstring, CommandType.Text, sql, new SqlParameter("@logid", logid));
           if (obj == null)
           {
               return 0;
           }
           else
           {
               return Convert.ToInt32(obj);
           }
       }

       public List<LogKind> GetAllKind(LogKind lk)
       {
           string sql = "select * from [LogKind] where userid="+lk.userid;
           List<LogKind> lok = new List<LogKind>();
           SqlDataReader sdr = SqlHelper.ExecuteReader(_connstring, CommandType.Text, sql);
           if (sdr == null)
           {
               return null;
           }
           else
           {
               while (sdr.Read())
               {
                   LogKind log = new LogKind();
                   log.logkind = sdr["logkind"].ToString();
                   log.logkindid = Convert.ToInt32(sdr["logkindid"]);
                   log.userid = Convert.ToInt32(sdr["userid"]);
                   lok.Add(log);
               }
               sdr.Close();
               sdr.Dispose();
           }
           return lok;
       }

       public List<LogView> GetLogView(int userid,int logkindid)
       {
           string sql = @"select lg.logid,lg.logtitle,lg.logdate,lg.logkindid,lk.userid,lk.logkind,lg.logcontenct from [LogView] as lg inner join dbo.LogKind as lk 
                            on lg.logkindid=lk.logkindid";
           if (userid!=0)
           {
               sql += " where lk.userid="+userid;
           }
           if (logkindid!=0)
           {
               sql += " and lg.logid="+logkindid;
           }
           List<LogView> lo = new List<LogView>();
           SqlDataReader sdr = SqlHelper.ExecuteReader(_connstring, CommandType.Text, sql);
           if (sdr == null)
           {
               return null;
           }
           else
           {
               while (sdr.Read())
               {
                   LogView log = new LogView();
                   log.logid = Convert.ToInt32(sdr["logid"]);
                   log.logtitle = sdr["logtitle"].ToString();
                   log.logkind = sdr["logkind"].ToString();
                   log.logcontenct = sdr["logcontenct"].ToString();
                   log.userid = Convert.ToInt32(sdr["userid"]);
                   log.logkindid = Convert.ToInt32(sdr["logkindid"]);
                   log.logdate = Convert.ToDateTime(sdr["logdate"]);
                   lo.Add(log);
               }
               sdr.Close();
               sdr.Dispose();
           }
           return lo;
       }
    }
}
