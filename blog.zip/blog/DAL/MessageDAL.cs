using System;
using System.Collections.Generic;
using System.Text;
using Model;
using System.Data;
using System.Data.SqlClient;


namespace DAL
{
    public class MessageDAL:Connstring
    {
        public List<Message> GetMessages()
        {
            List<Message> lm = new List<Message>();
            string sql = "select * from [Message]";
            SqlDataReader sdr = SqlHelper.ExecuteReader(_connstring, CommandType.Text, sql);
            if (sdr!=null)
            {
                while (sdr.Read())
                {
                    Message m = new Message();
                    m.msgid = Convert.ToInt32(sdr["msgid"]);
                    m.msguserid = Convert.ToInt32(sdr["msguserid"]);
                    m.msg = sdr["msg"].ToString();
                    m.msgdate = Convert.ToDateTime(sdr["msgdate"]);
                    m.msgusername = sdr["msgusername"].ToString();
                    lm.Add(m);
                }
            }
            return lm;
        }
        public List<Message> GetMessages(int userid)
        {
            List<Message> lm = new List<Message>();
            string sql = "select * from [Message] where msguserid=" + userid;
            SqlDataReader sdr = SqlHelper.ExecuteReader(_connstring, CommandType.Text, sql);
            if (sdr != null)
            {
                while (sdr.Read())
                {
                    Message m = new Message();
                    m.msgid = Convert.ToInt32(sdr["msgid"]);
                    m.msguserid = Convert.ToInt32(sdr["msguserid"]);
                    m.msg = sdr["msg"].ToString();
                    m.msgdate = Convert.ToDateTime(sdr["msgdate"]);
                    m.msgusername = sdr["msgusername"].ToString();
                    lm.Add(m);
                }
            }
            return lm;
        }
        public Message GetSingleMessage(int msgid)
        {
            Message m = new Message();
            string sql = "select * from [Message] where msgid=" + msgid;
            SqlDataReader sdr = SqlHelper.ExecuteReader(_connstring, CommandType.Text, sql);
            if (sdr != null)
            {
                while (sdr.Read())
                {
                    
                    m.msgid = Convert.ToInt32(sdr["msgid"]);
                    m.msguserid = Convert.ToInt32(sdr["msguserid"]);
                    m.msg = sdr["msg"].ToString();
                    m.msgdate = Convert.ToDateTime(sdr["msgdate"]);
                    m.msgusername = sdr["msgusername"].ToString();
                }
            }
            return m;
        }
        public int InsertMessage(Message m)
        {
            string sql = "insert into [Message](msguserid,msg,msgdate,msgusername) values(@msguserid,@msg,@msgdate,@msgusername)";
            return SqlHelper.ExecuteNonQuery(_connstring, CommandType.Text, sql, new SqlParameter("@msguserid", m.msguserid), new SqlParameter("@msg", m.msg), new SqlParameter("@msgdate", m.msgdate), new SqlParameter("@msgusername", m.msgusername));
        }
        public int UpdateMessage(Message m)
        {
            string sql = "update [Message] set msg=@msg,msgdate=@msgdate,msgusername=@msgusername where msgid=@msgid";
            return SqlHelper.ExecuteNonQuery(_connstring, CommandType.Text, sql, new SqlParameter("@msgid", m.msgid), new SqlParameter("@msg", m.msg), new SqlParameter("@msgdate", m.msgdate), new SqlParameter("@msgusername", m.msgusername));
        }
        public int DeleteMessage(int msgid)
        {
            string sql = "Delete from [Message]  where msgid=@msgid";
            return SqlHelper.ExecuteNonQuery(_connstring, CommandType.Text, sql, new SqlParameter("@msgid",msgid));
        }
    }
}
